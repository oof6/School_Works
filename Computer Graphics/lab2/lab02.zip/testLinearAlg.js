function main()
{


    var v1 = [1,2,3,4];
    var v2 = [5,6,7,8];

    var m1 = [
    [1.0, 2.0, 3.0, 4.0],  // first column
    [-5.0, 6.0, 7.0, 8.0],  // second column
    [9.0, -10.0, 11.0, 12.0],  // third column
    [13.0, 14.0, 15.0, -16.0]];

    var m2 = [
    [4.0, 3.0, 2.0, 1.0],  // first column
    [8.0, 7.0, 6.0, 5.0],  // second column
    [12.0, 11.0, 10.0, 9.0],  // third column
    [16.0, 15.0, 14.0, 13.0]];

    var s = 3.0;


//tests
//////////////////
    document.ready = console.log("vector v1:");
    document.ready = print4x1(v1);
    document.ready = console.log("vector v2:");
    document.ready = print4x1(v2);
    document.ready = console.log("scalar s: " + s);
    
    document.ready = console.log("s * v1: ");
    document.ready = print4x1(scalVecMult(s,v1));
    document.ready = console.log("v1 + v2: ");
    document.ready = print4x1(vecVecAdd(v1,v2));
    document.ready = console.log("v1 - v2: ");
    document.ready = print4x1(vecVecSub(v1,v2));
    document.ready = console.log("|v1|(magnitude): " + vecMag(v1));

    document.ready = console.log("Normalized v1: ");
    document.ready = print4x1(norm(v1));
    document.ready = console.log("v1 . v2 (dot product): ");
    document.ready = console.log(dotProd(v1,v2));
    document.ready = console.log("v1 x v2 (cross product): ");
    document.ready = print4x1(crossProd(v1,v2));
    document.ready = console.log("Matrix m1: ");
    document.ready = printMat(m1);

    document.ready = console.log("Matrix m2: ");
    document.ready = printMat(m2);

    document.ready = console.log("s * m1: ");
    document.ready = printMat(scalMat(s,m1));
    document.ready = console.log("m1 + m2: ");
    document.ready = printMat(matMatAdd(m1,m2));
    document.ready = console.log("m1 - m2: ");
    document.ready = printMat(matMatSub(m1,m2));
    document.ready = console.log("m1 * m2: ");
    document.ready = printMat(matMatMult(m2,m1));
    document.ready = console.log("m1^T (transpose) : ");

    document.ready = printMat(transMat(m1));
    document.ready = console.log("m1^{-1} (inverse) : ");
    document.ready = printMat(invMat(m1));
    document.ready = console.log("m1 * v1: ");
    document.ready = print4x1(matVecMult(m1,v1));
    document.ready = console.log("m1 * m1^{-1}: ");
    document.ready = printMat(matMatMult(m1,invMat(m1)));
    document.ready = console.log("m1^{-1} * m1: ");

    document.ready = printMat(matMatMult(invMat(m1),m1));

/////////////////////////////////
  
}